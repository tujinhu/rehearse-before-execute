"""Local-only static server with byte-range support for MP4 seeking."""
import argparse,functools,http.server,mimetypes,re,socketserver
from pathlib import Path
ROOT=Path(__file__).resolve().parent
class Handler(http.server.SimpleHTTPRequestHandler):
    def send_head(self):
        path=Path(self.translate_path(self.path))
        if not path.is_file() or 'Range' not in self.headers:return super().send_head()
        size=path.stat().st_size;match=re.fullmatch(r'bytes=(\d*)-(\d*)',self.headers['Range'].strip())
        if not match or not any(match.groups()):self.send_error(416);return None
        left,right=match.groups()
        if left:start=int(left);end=int(right) if right else size-1
        else:start=max(0,size-int(right));end=size-1
        if start>=size or end<start:
            self.send_response(416);self.send_header('Content-Range',f'bytes */{size}');self.end_headers();return None
        end=min(end,size-1);self._remaining=end-start+1
        self.send_response(206);self.send_header('Content-Type',mimetypes.guess_type(str(path))[0] or 'application/octet-stream')
        self.send_header('Content-Length',str(self._remaining));self.send_header('Content-Range',f'bytes {start}-{end}/{size}');self.send_header('Accept-Ranges','bytes');self.end_headers()
        f=path.open('rb');f.seek(start);return f
    def copyfile(self,source,outputfile):
        if not hasattr(self,'_remaining'):return super().copyfile(source,outputfile)
        remaining=self._remaining
        while remaining:
            data=source.read(min(65536,remaining))
            if not data:break
            try:outputfile.write(data)
            except (BrokenPipeError,ConnectionResetError):break
            remaining-=len(data)
        del self._remaining
    def end_headers(self):
        self.send_header('X-Content-Type-Options','nosniff');super().end_headers()
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8765);a=p.parse_args()
    mimetypes.add_type('text/vtt','.vtt');mimetypes.add_type('video/mp4','.mp4')
    with http.server.ThreadingHTTPServer(('127.0.0.1',a.port),functools.partial(Handler,directory=str(ROOT))) as s:
        print(f'Preview: http://127.0.0.1:{a.port}',flush=True)
        try:s.serve_forever()
        except KeyboardInterrupt:pass
