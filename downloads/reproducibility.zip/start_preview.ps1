param([int]$Port=8765)
$ErrorActionPreference='Stop'
$previewPython = Get-Command python -ErrorAction SilentlyContinue
if ($previewPython) { $previewPythonPath=$previewPython.Source }
else { $previewPythonPath=Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' }
if (-not (Test-Path -LiteralPath $previewPythonPath)) { throw 'Please install Python 3, then run: python serve.py' }
Write-Host "Open http://127.0.0.1:$Port ; press Ctrl+C to stop."
& $previewPythonPath (Join-Path $PSScriptRoot 'serve.py') --port $Port
