# Rehearse Before Execute — 论文展示网页

沿用用户指定模板的版式、字体与紫金色系。本次更新使用 networkV2.pdf，新增按动作事件估计对齐的 RflySim / 真机录像展示，总览改为原创合成轻音乐，无说明配音。

预览：运行 `python serve.py`，打开 http://127.0.0.1:8765/ 。

**详细修改及公开发布步骤见 [编辑与发布指南.md](编辑与发布指南.md)。**

- 长期维护：修改 `build/build_page.py` 后重新生成 `index.html`。直接编辑成品 HTML 也可，但不要随后重新生成覆盖它。
- 样式：`assets/site.css`；图件：`assets/figures/`；视频：`media/`；数据：`data/`。
- 总览 180 秒；工具链视频约 46 秒；其他 9 个示意及数据视频保留。总览与工具链片段均仅有音乐，短片自动播放默认静音。
- 录像来自 `data/<场景>/sim/<动作>/video` 和 `real/<动作>/video`。来源、剪辑区间、倍率及哈希见 `data/footage_sources.json`。采用可见起飞与日志事件估计视频时钟偏移，对齐至各自动作事件；共享计时、原录像时钟、日志高度曲线和故障至动作延迟均在视频中展示。两侧统一 0.5 倍速，不独立变速。估计对齐不等于硬件同步或同初态配对。详细记录见 data/action_alignment.json。
- 网络图来源：`../network_model/output/networkV2.pdf`。
- 保真度表对应原论文组图 (a–h) 的八项响应，DT / PD–AR(1) / ZI 最优项数为 4 / 2 / 2。网页不再展示完整十二项展开表，也不提供单独 CSV 下载按钮；原始数据在本地保留，制作代码包内仍包含来源数据。
- 189 条数据是九个原始案例与 180 条统计扩充，政策匹配率不等于实飞安全成功率。
- `downloads/reproducibility.zip` 为网页、视频制作代码与图件数据，不是完整飞控仿真工具链。复现录影片段需要本地项目原始录像；其余成品可独立预览和部署。

重新制作：

```powershell
python build/prepare_site.py
python build/render_videos.py --only overview
python build/compose_media.py
python build/build_page.py
python build/package_and_check.py
```

Python 依赖：Pillow、numpy、pymupdf、imageio-ffmpeg。修改其他动画时可运行 `render_videos.py --only support`。当前不使用语音合成流程。

上一级 `Rehearse_Before_Execute_Website.zip` 为完整制作交付包；`Rehearse_Before_Execute_Deploy.zip` 为部署包，解压第一层即为 index.html。只需将部署包内容放到静态托管服务即可。当前未公开部署。

版式参考：https://icra27-async-robosim.dgrnd8pzg9mss.amplifyapp.com/

工具链：https://rflysim.com/doc/en/4.DevRef/frame.html
